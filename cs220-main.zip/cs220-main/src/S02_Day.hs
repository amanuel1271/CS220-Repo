module S02_Day
  ( Day
  ) where

data Day = Sunday | Monday | Tuesday | Wednesday | Thursday | Friday | Saturday

v1 :: Day
v1 = Sunday

v2 :: Day
v2 = Thursday

v3 :: Bool
v3 = False

v4 :: Bool
v4 = True
