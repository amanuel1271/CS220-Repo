module S02_Primitive
  ( v1
  , v2
  , v3
  , v4
  , v5
  , v6
  ) where


v1 :: ()    -- v1's type
v1 = ()     -- v1's value

v2 :: Char
v2 = 'j'

v3 :: Integer
v3 = 42

v4 :: Int
v4 = 42

v5 :: Float
v5 = 42.0

v6 :: Double
v6 = 42.0
